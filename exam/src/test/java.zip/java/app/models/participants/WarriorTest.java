package app.models.participants;

import app.contracts.Targetable;

import app.models.Config;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import static org.junit.Assert.*;


public class WarriorTest {

    private Targetable targetable1;
    private Targetable targetable2;
    private Warrior testTarget;
    private static final double DELTA = 1e-15;

    @Before
    public void before() {

        this.targetable1 = Mockito.mock(Warrior.class);
        this.targetable2 = Mockito.mock(Targetable.class);

        Mockito.when(targetable1.getDamage()).thenReturn(9.0);
        Mockito.when(targetable1.getGold()).thenReturn(399.0);
        Mockito.when(targetable2.getDamage()).thenReturn(51.0);

        testTarget = new Warrior();

    }

    @Test
    public void takingDamageCorrectly(){
       testTarget.takeDamage(targetable1.getDamage());

        Assert.assertEquals(41.0,testTarget.getHealth(),DELTA);
    }

    @Test
    public void isAliveCorrectly(){

        Assert.assertEquals(true,testTarget.isAlive());

        testTarget.takeDamage(targetable2.getDamage());

        Assert.assertEquals(false,testTarget.isAlive());
    }

    @Test
    public void levelUpCorrectly(){
        testTarget.levelUp();

        Assert.assertEquals(Config.WARRIOR_BASE_STRENGTH * 2 ,testTarget.getStrength());
    }

    @Test
    public void recieveRewardCorrectly(){
        testTarget.receiveReward(targetable1.getGold());

        Assert.assertEquals(Config.HERO_START_GOLD + 399.0,testTarget.getGold(),DELTA);
    }

}
